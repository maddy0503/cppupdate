#pragma once
#include <istream>
#include <optional>
#include <ostream>
#include <vector>

#include "hotel/cli/input_reader.hpp"
#include "hotel/hotel.hpp"

namespace hotel::cli {

// Interactive menu. Streams are injected so tests can script a session.
class Cli {
public:
    Cli(Hotel& hotel, std::istream& in, std::ostream& out)
        : hotel_(hotel), out_(out), input_(in, out) {}

    // Runs the menu loop until "Exit" or end of input. Returns a process exit code.
    int run();

private:
    // menu actions
    void registerGuest();
    void showAvailable();
    void bookRoom();
    void checkIn();
    void checkOut();
    void cancelBooking();
    void addService();
    void findGuest();
    void listRooms();

    // helpers
    void printMenu();
    void printRooms(const std::vector<const Room*>& rooms);
    void printBooking(const Booking& b);
    std::optional<RoomType> askType();
    void report(bool ok, const std::string& err);

    Hotel& hotel_;
    std::ostream& out_;
    InputReader input_;
};

}  // namespace hotel::cli
