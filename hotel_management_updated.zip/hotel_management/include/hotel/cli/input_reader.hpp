#pragma once
#include <istream>
#include <ostream>
#include <stdexcept>
#include <string>

namespace hotel::cli {

// Thrown when the input stream ends (Ctrl-D / EOF).
class EndOfInput : public std::runtime_error {
public:
    EndOfInput() : std::runtime_error("end of input") {}
};

// Prompting helpers that keep asking until the answer is valid.
class InputReader {
public:
    InputReader(std::istream& in, std::ostream& out) : in_(in), out_(out) {}

    std::string line(const std::string& prompt);
    std::string nonEmpty(const std::string& prompt);
    int integer(const std::string& prompt, int lo, int hi);
    double amount(const std::string& prompt);
    int day(const std::string& prompt);

private:
    std::istream& in_;
    std::ostream& out_;
};

}  // namespace hotel::cli
