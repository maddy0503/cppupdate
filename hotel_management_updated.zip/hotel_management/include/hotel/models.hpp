#pragma once
#include <string>

namespace hotel {

enum class BookingStatus { Booked, CheckedIn, CheckedOut, Cancelled };

struct Guest {
    int id;
    std::string name;
    std::string phone;
};

struct Booking {
    int id;
    int guestId;
    int roomNo;
    int startDay;
    int nights;
    BookingStatus status;
    double services;  // food, laundry, etc.
    int endDay() const { return startDay + nights; }
};

const char* statusName(BookingStatus s);

}  // namespace hotel
