#pragma once
#include <memory>
#include <string>

namespace hotel {

enum class RoomType { Single, Double, Deluxe, Suite };

class Room {
public:
    explicit Room(int number) : number_(number) {}
    virtual ~Room() = default;
    int number() const { return number_; }
    virtual RoomType type() const = 0;
    virtual std::string typeName() const = 0;
    virtual double pricePerNight() const = 0;
    virtual int capacity() const = 0;

private:
    int number_;
};

class SingleRoom : public Room {
public:
    using Room::Room;
    RoomType type() const override { return RoomType::Single; }
    std::string typeName() const override { return "Single"; }
    double pricePerNight() const override { return 1500; }
    int capacity() const override { return 1; }
};

class DoubleRoom : public Room {
public:
    using Room::Room;
    RoomType type() const override { return RoomType::Double; }
    std::string typeName() const override { return "Double"; }
    double pricePerNight() const override { return 2500; }
    int capacity() const override { return 2; }
};

class DeluxeRoom : public Room {
public:
    using Room::Room;
    RoomType type() const override { return RoomType::Deluxe; }
    std::string typeName() const override { return "Deluxe"; }
    double pricePerNight() const override { return 4000; }
    int capacity() const override { return 3; }
};

class SuiteRoom : public Room {
public:
    using Room::Room;
    RoomType type() const override { return RoomType::Suite; }
    std::string typeName() const override { return "Suite"; }
    double pricePerNight() const override { return 7000; }
    int capacity() const override { return 4; }
};

std::unique_ptr<Room> makeRoom(RoomType type, int number);

}  // namespace hotel
