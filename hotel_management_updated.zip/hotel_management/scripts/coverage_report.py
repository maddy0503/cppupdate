#!/usr/bin/env python3
"""Line / function / branch coverage summary from gcov's JSON output (GCC >= 9).

Usage: coverage_report.py <build-dir> [--root DIR] [--include PFX ...]
Env:   COVERAGE_MIN         minimum line coverage %      (default 0)
       COVERAGE_FUNC_MIN    minimum function coverage %  (default 0)
       COVERAGE_BRANCH_MIN  minimum branch coverage %    (default 0)

Branches that only exist for exception unwinding ("throw" branches) are not
counted, because they are not reachable by normal test inputs.
"""
import argparse, json, os, subprocess, sys
from collections import defaultdict


def ranges(nums):
    out, start, prev = [], None, None
    for n in sorted(nums):
        if start is None:
            start = prev = n
        elif n == prev + 1:
            prev = n
        else:
            out.append((start, prev)); start = prev = n
    if start is not None:
        out.append((start, prev))
    return ",".join(str(a) if a == b else f"{a}-{b}" for a, b in out)


def pct(hit, tot):
    return 100.0 if tot == 0 else 100.0 * hit / tot


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("build")
    ap.add_argument("--root", default=os.getcwd())
    ap.add_argument("--include", nargs="*", default=["src/", "include/"])
    a = ap.parse_args()
    root = os.path.realpath(a.root)

    gcdas = []
    for d, _, files in os.walk(a.build):
        gcdas += [os.path.join(d, f) for f in files if f.endswith(".gcda")]
    if not gcdas:
        sys.exit("no .gcda files found - did the tests run?")

    lines = defaultdict(lambda: defaultdict(int))      # file -> line -> count
    branches = defaultdict(lambda: defaultdict(list))  # file -> line -> [count per branch]
    funcs = defaultdict(lambda: defaultdict(int))      # file -> function -> count

    for gcda in sorted(gcdas):
        r = subprocess.run(["gcov", "--json-format", "--stdout", "--branch-probabilities", gcda],
                           cwd=root, capture_output=True, text=True)
        for doc in r.stdout.splitlines():
            if not doc.strip():
                continue
            data = json.loads(doc)
            cwd = data.get("current_working_directory", root)
            for f in data["files"]:
                path = os.path.realpath(os.path.join(cwd, f["file"]))
                rel = os.path.relpath(path, root)
                if not any(rel.startswith(p) for p in a.include):
                    continue
                for ln in f["lines"]:
                    n = ln["line_number"]
                    lines[rel][n] += ln["count"]
                    real = [b["count"] for b in ln.get("branches", []) if not b.get("throw")]
                    cur = branches[rel][n]
                    for i, c in enumerate(real):
                        if i < len(cur):
                            cur[i] += c
                        else:
                            cur.append(c)
                for fn in f.get("functions", []):
                    funcs[rel][fn.get("demangled_name", fn["name"])] += fn["execution_count"]

    files = sorted(set(lines) | set(funcs))
    if not files:
        sys.exit("no coverage data for " + ", ".join(a.include))

    W = max(len(f) for f in files + ["TOTAL"]) + 2
    hdr = f"{'FILE':<{W}}{'LINES':>16}{'FUNCTIONS':>16}{'BRANCHES':>16}   MISSING LINES"
    out = ["", hdr, "-" * len(hdr)]
    T = defaultdict(int)

    def cell(h, t):
        return f"{h}/{t} {pct(h, t):5.1f}%"

    for f in files:
        lh = sum(1 for c in lines[f].values() if c > 0); lt = len(lines[f])
        fh = sum(1 for c in funcs[f].values() if c > 0); ft = len(funcs[f])
        bh = sum(1 for bl in branches[f].values() for c in bl if c > 0)
        bt = sum(len(bl) for bl in branches[f].values())
        miss = ranges([n for n, c in lines[f].items() if c == 0])
        out.append(f"{f:<{W}}{cell(lh, lt):>16}{cell(fh, ft):>16}{cell(bh, bt):>16}   {miss}")
        for k, v in zip(("lh", "lt", "fh", "ft", "bh", "bt"), (lh, lt, fh, ft, bh, bt)):
            T[k] += v
    out.append("-" * len(hdr))
    out.append(f"{'TOTAL':<{W}}{cell(T['lh'], T['lt']):>16}{cell(T['fh'], T['ft']):>16}"
               f"{cell(T['bh'], T['bt']):>16}")
    out.append("")
    out.append(f"Line coverage:     {pct(T['lh'], T['lt']):6.2f}%  ({T['lh']} of {T['lt']} lines)")
    out.append(f"Function coverage: {pct(T['fh'], T['ft']):6.2f}%  ({T['fh']} of {T['ft']} functions)")
    out.append(f"Branch coverage:   {pct(T['bh'], T['bt']):6.2f}%  ({T['bh']} of {T['bt']} branches, exception branches excluded)")
    text = "\n".join(out)
    print(text)
    os.makedirs(os.path.join(a.build, "report"), exist_ok=True)
    with open(os.path.join(a.build, "report", "coverage.txt"), "w") as fh:
        fh.write(text + "\n")

    failed = False
    for name, got, env in (("line", pct(T['lh'], T['lt']), "COVERAGE_MIN"),
                           ("function", pct(T['fh'], T['ft']), "COVERAGE_FUNC_MIN"),
                           ("branch", pct(T['bh'], T['bt']), "COVERAGE_BRANCH_MIN")):
        need = float(os.environ.get(env, "0") or 0)
        if got < need:
            print(f"FAIL: {name} coverage {got:.1f}% is below required {need:g}% ({env})", file=sys.stderr)
            failed = True
    sys.exit(1 if failed else 0)


if __name__ == "__main__":
    main()
