#include "hotel/cli/input_reader.hpp"

#include "hotel/date_utils.hpp"

namespace hotel::cli {

std::string InputReader::line(const std::string& prompt) {
    out_ << prompt;
    std::string s;
    if (!std::getline(in_, s)) throw EndOfInput();
    size_t a = s.find_first_not_of(" \t\r"), b = s.find_last_not_of(" \t\r");
    return a == std::string::npos ? "" : s.substr(a, b - a + 1);
}

std::string InputReader::nonEmpty(const std::string& prompt) {
    while (true) {
        std::string s = line(prompt);
        if (!s.empty()) return s;
        out_ << "  This cannot be empty.\n";
    }
}

int InputReader::integer(const std::string& prompt, int lo, int hi) {
    while (true) {
        std::string s = line(prompt);
        try {
            size_t p;
            int v = std::stoi(s, &p);
            if (p == s.size() && v >= lo && v <= hi) return v;
        } catch (...) {}
        out_ << "  Please enter a number from " << lo << " to " << hi << ".\n";
    }
}

double InputReader::amount(const std::string& prompt) {
    while (true) {
        std::string s = line(prompt);
        try {
            size_t p;
            double v = std::stod(s, &p);
            if (p == s.size() && v > 0) return v;
        } catch (...) {}
        out_ << "  Please enter a positive amount.\n";
    }
}

int InputReader::day(const std::string& prompt) {
    while (true) {
        if (auto d = parseDate(line(prompt))) return *d;
        out_ << "  Use a valid date as YYYY-MM-DD.\n";
    }
}

}  // namespace hotel::cli
