#include "hotel/cli/cli.hpp"

#include <iomanip>

#include "hotel/date_utils.hpp"

namespace hotel::cli {

// ---------- display helpers ----------
void Cli::printMenu() {
    out_ << "\n 1 Register guest      2 Check availability   3 Book a room\n"
            " 4 Check in            5 Check out + invoice  6 Cancel booking\n"
            " 7 Add service charge  8 Find guest/bookings  9 List all rooms\n"
            " 0 Exit\n";
}

void Cli::printRooms(const std::vector<const Room*>& rooms) {
    if (rooms.empty()) { out_ << "  No rooms found.\n"; return; }
    out_ << "  Room  Type     Guests  Price/night\n";
    for (const Room* r : rooms)
        out_ << "  " << std::left << std::setw(6) << r->number() << std::setw(9) << r->typeName()
             << std::setw(8) << r->capacity() << "Rs. " << static_cast<int>(r->pricePerNight()) << "\n";
}

void Cli::printBooking(const Booking& b) {
    const Guest* g = hotel_.findGuest(b.guestId);
    out_ << "  Booking #" << b.id << " | " << (g ? g->name : "?") << " | Room " << b.roomNo << " | "
         << dayToString(b.startDay) << " to " << dayToString(b.endDay()) << " | "
         << statusName(b.status) << "\n";
}

std::optional<RoomType> Cli::askType() {
    out_ << "  Room type: 1 Single  2 Double  3 Deluxe  4 Suite  0 Any\n";
    int t = input_.integer("  Choice: ", 0, 4);
    if (t == 0) return std::nullopt;
    return static_cast<RoomType>(t - 1);
}

void Cli::report(bool ok, const std::string& err) {
    if (ok) { hotel_.save(); out_ << "  Done.\n"; }
    else out_ << "  Error: " << err << "\n";
}

// ---------- menu actions ----------
void Cli::registerGuest() {
    std::string name = input_.nonEmpty("  Guest name: ");
    std::string phone = input_.nonEmpty("  Phone: ");
    int id = hotel_.registerGuest(name, phone);
    hotel_.save();
    out_ << "  Registered. Your guest ID is " << id << ".\n";
}

void Cli::showAvailable() {
    int start = input_.day("  Check-in date (YYYY-MM-DD): ");
    int nights = input_.integer("  Nights: ", 1, 365);
    auto type = askType();
    int maxP = input_.integer("  Max price per night (0 = no limit): ", 0, 1000000);
    printRooms(hotel_.availableRooms(start, nights, type, maxP));
}

void Cli::bookRoom() {
    int gid = input_.integer("  Guest ID: ", 1, 1000000);
    if (!hotel_.findGuest(gid)) {
        out_ << "  No guest with that ID. Register first (option 1).\n";
        return;
    }
    int start = input_.day("  Check-in date (YYYY-MM-DD): ");
    int nights = input_.integer("  Nights: ", 1, 365);
    auto type = askType();
    auto rooms = hotel_.availableRooms(start, nights, type, 0);
    printRooms(rooms);
    if (rooms.empty()) return;
    int room = input_.integer("  Room number to book (0 to cancel): ", 0, 100000);
    if (room == 0) return;
    std::string err;
    int id = hotel_.book(gid, room, start, nights, err);
    if (id < 0) { out_ << "  Error: " << err << "\n"; return; }
    hotel_.save();
    out_ << "  Booked! Your booking ID is " << id << ".\n";
}

void Cli::checkIn() {
    std::string err;
    int id = input_.integer("  Booking ID: ", 1, 1000000);
    report(hotel_.checkIn(id, err), err);
}

void Cli::checkOut() {
    std::string err, invoice;
    int id = input_.integer("  Booking ID: ", 1, 1000000);
    bool ok = hotel_.checkOut(id, invoice, err);
    report(ok, err);
    if (ok) out_ << invoice;
}

void Cli::cancelBooking() {
    std::string err;
    int id = input_.integer("  Booking ID: ", 1, 1000000);
    report(hotel_.cancel(id, err), err);
}

void Cli::addService() {
    int id = input_.integer("  Booking ID: ", 1, 1000000);
    double amt = input_.amount("  Service amount (Rs.): ");
    std::string err;
    report(hotel_.addService(id, amt, err), err);
}

void Cli::findGuest() {
    std::string key = input_.nonEmpty("  Guest ID or part of name: ");
    std::vector<const Guest*> found;
    try {
        size_t p;
        int id = std::stoi(key, &p);
        if (p == key.size()) {
            if (auto* g = hotel_.findGuest(id)) found.push_back(g);
        } else {
            found = hotel_.searchGuests(key);
        }
    } catch (...) {
        found = hotel_.searchGuests(key);
    }
    if (found.empty()) { out_ << "  No guest found.\n"; return; }
    for (const Guest* g : found) {
        out_ << "  Guest " << g->id << ": " << g->name << " (" << g->phone << ")\n";
        auto bs = hotel_.bookingsFor(g->id);
        if (bs.empty()) out_ << "    No bookings.\n";
        for (const Booking* b : bs) { out_ << "  "; printBooking(*b); }
    }
}

void Cli::listRooms() {
    out_ << "  Room  Type     Guests  Price/night  Now\n";
    for (const auto& r : hotel_.rooms())
        out_ << "  " << std::left << std::setw(6) << r->number() << std::setw(9) << r->typeName()
             << std::setw(8) << r->capacity() << std::setw(13)
             << ("Rs. " + std::to_string(static_cast<int>(r->pricePerNight())))
             << (hotel_.isOccupiedToday(r->number()) ? "Occupied" : "Free") << "\n";
}

// ---------- main loop ----------
int Cli::run() {
    out_ << "=== Hotel Management System ===\n";
    try {
        while (true) {
            printMenu();
            switch (input_.integer("Choose: ", 0, 9)) {
                case 1: registerGuest(); break;
                case 2: showAvailable(); break;
                case 3: bookRoom(); break;
                case 4: checkIn(); break;
                case 5: checkOut(); break;
                case 6: cancelBooking(); break;
                case 7: addService(); break;
                case 8: findGuest(); break;
                case 9: listRooms(); break;
                case 0: hotel_.save(); out_ << "Goodbye.\n"; return 0;
            }
        }
    } catch (const EndOfInput&) {
        hotel_.save();
        out_ << "\nGoodbye.\n";
    }
    return 0;
}

}  // namespace hotel::cli
