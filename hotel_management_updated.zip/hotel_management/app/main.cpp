#include <iostream>

#include "hotel/cli/cli.hpp"
#include "hotel/hotel.hpp"

int main() {
    hotel::Hotel hotel("data");
    if (!hotel.load()) {
        std::cerr << "Could not read or write the data folder.\n";
        return 1;
    }
    hotel::cli::Cli cli(hotel, std::cin, std::cout);
    return cli.run();
}
