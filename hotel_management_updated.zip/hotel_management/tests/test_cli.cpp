#include <gtest/gtest.h>

#include <sstream>

#include "hotel/cli/cli.hpp"
#include "hotel/cli/input_reader.hpp"
#include "hotel/date_utils.hpp"
#include "hotel/hotel.hpp"
#include "test_support.hpp"

using namespace hotel;
using hotel::cli::Cli;
using hotel::cli::EndOfInput;
using hotel::cli::InputReader;

namespace {
bool contains(const std::string& text, const std::string& part) {
    return text.find(part) != std::string::npos;
}
}  // namespace

// ---------- InputReader ----------
TEST(InputReader, LineTrimsWhitespace) {
    std::istringstream in("  hello world \t\r\n   \n");
    std::ostringstream out;
    InputReader r(in, out);
    EXPECT_EQ(r.line("> "), "hello world");
    EXPECT_EQ(r.line("> "), "");
    EXPECT_EQ(out.str(), "> > ");
}

TEST(InputReader, ThrowsAtEndOfInput) {
    std::istringstream in("");
    std::ostringstream out;
    InputReader r(in, out);
    EXPECT_THROW(r.line("> "), EndOfInput);
}

TEST(InputReader, IntegerRetriesUntilValid) {
    std::istringstream in("abc\n12x\n99\n-1\n5\n");
    std::ostringstream out;
    InputReader r(in, out);
    EXPECT_EQ(r.integer("n: ", 0, 9), 5);
    EXPECT_TRUE(contains(out.str(), "Please enter a number from 0 to 9."));
}

TEST(InputReader, AmountRetriesUntilPositive) {
    std::istringstream in("x\n0\n-3\n1.5kg\n42.5\n");
    std::ostringstream out;
    InputReader r(in, out);
    EXPECT_DOUBLE_EQ(r.amount("amt: "), 42.5);
    EXPECT_TRUE(contains(out.str(), "Please enter a positive amount."));
}

TEST(InputReader, DayRetriesUntilValid) {
    std::istringstream in("tomorrow\n2023-02-30\n2024-02-29\n");
    std::ostringstream out;
    InputReader r(in, out);
    EXPECT_EQ(r.day("date: "), daysFromCivil(2024, 2, 29));
    EXPECT_TRUE(contains(out.str(), "Use a valid date as YYYY-MM-DD."));
}

TEST(InputReader, NonEmptyRetries) {
    std::istringstream in("\n   \nbob\n");
    std::ostringstream out;
    InputReader r(in, out);
    EXPECT_EQ(r.nonEmpty("name: "), "bob");
    EXPECT_TRUE(contains(out.str(), "This cannot be empty."));
}

// ---------- full menu ----------
class CliTest : public ::testing::Test {
protected:
    void SetUp() override { ASSERT_TRUE(hotel_.load()); }

    // Runs the menu with scripted input; returns everything it printed.
    std::string run(const std::string& script, int* exitCode = nullptr) {
        std::istringstream in(script);
        std::ostringstream out;
        Cli cli(hotel_, in, out);
        int code = cli.run();
        if (exitCode) *exitCode = code;
        return out.str();
    }

    static std::string tomorrowStr() { return dayToString(test::tomorrow()); }

    test::TempDir dir_;
    Hotel hotel_{dir_.str()};
};

TEST_F(CliTest, ExitSaysGoodbye) {
    int code = -1;
    std::string out = run("0\n", &code);
    EXPECT_EQ(code, 0);
    EXPECT_TRUE(contains(out, "Hotel Management System"));
    EXPECT_TRUE(contains(out, "Goodbye."));
}

TEST_F(CliTest, EndOfInputIsTreatedAsExit) {
    int code = -1;
    std::string out = run("", &code);
    EXPECT_EQ(code, 0);
    EXPECT_TRUE(contains(out, "Goodbye."));
}

TEST_F(CliTest, InvalidMenuChoiceReprompts) {
    std::string out = run("hello\n42\n0\n");
    EXPECT_TRUE(contains(out, "Please enter a number from 0 to 9."));
}

TEST_F(CliTest, RegisterGuest) {
    std::string out = run("1\n\nAlice Smith\n555-1234\n0\n");
    EXPECT_TRUE(contains(out, "This cannot be empty."));
    EXPECT_TRUE(contains(out, "Registered. Your guest ID is 1."));
    ASSERT_NE(hotel_.findGuest(1), nullptr);
    EXPECT_EQ(hotel_.findGuest(1)->name, "Alice Smith");
}

TEST_F(CliTest, FullStayFromBookingToInvoice) {
    const std::string d = tomorrowStr();
    std::string script =
        "1\nAlice\n555\n"            // register -> guest 1
        "3\n1\n" + d + "\n2\n1\n101\n"  // book single room 101 for 2 nights
        "4\n1\n"                     // check in
        "7\n1\nabc\n-5\n500\n"       // add service (with invalid retries)
        "5\n1\n"                     // check out
        "0\n";
    std::string out = run(script);
    EXPECT_TRUE(contains(out, "Booked! Your booking ID is 1."));
    EXPECT_TRUE(contains(out, "Please enter a positive amount."));
    EXPECT_TRUE(contains(out, "INVOICE"));
    EXPECT_TRUE(contains(out, "3920.00"));
    EXPECT_EQ(hotel_.findBooking(1)->status, BookingStatus::CheckedOut);
}

TEST_F(CliTest, ChangesArePersistedToDisk) {
    run("1\nAlice\n555\n0\n");
    Hotel reloaded(dir_.str());
    ASSERT_TRUE(reloaded.load());
    EXPECT_NE(reloaded.findGuest(1), nullptr);
}

TEST_F(CliTest, BookingUnknownGuestIsRejected) {
    std::string out = run("3\n5\n0\n");
    EXPECT_TRUE(contains(out, "No guest with that ID. Register first"));
}

TEST_F(CliTest, BookingCanBeAbandonedAtRoomPrompt) {
    hotel_.registerGuest("Alice", "1");
    std::string out = run("3\n1\n" + tomorrowStr() + "\n1\n0\n0\n0\n");
    EXPECT_FALSE(contains(out, "Booked!"));
    EXPECT_TRUE(hotel_.bookingsFor(1).empty());
}

TEST_F(CliTest, BookingShowsErrorFromHotel) {
    hotel_.registerGuest("Alice", "1");
    // Room 999 does not exist; a past date is also rejected by the hotel.
    std::string out = run("3\n1\n" + tomorrowStr() + "\n1\n0\n999\n"
                          "3\n1\n2000-01-01\n1\n0\n101\n0\n");
    EXPECT_TRUE(contains(out, "Error: No such room."));
    EXPECT_TRUE(contains(out, "Error: Check-in date is in the past."));
}

TEST_F(CliTest, BookingWithNoFreeRoomsOfTypeSaysSo) {
    int g = hotel_.registerGuest("Alice", "1");
    std::string err;
    ASSERT_GT(hotel_.book(g, 401, test::tomorrow(), 1, err), 0);
    std::string out = run("3\n1\n" + tomorrowStr() + "\n1\n4\n0\n");  // only suite is 401
    EXPECT_TRUE(contains(out, "No rooms found."));
}

TEST_F(CliTest, AvailabilityListing) {
    std::string out = run("2\nnot-a-date\n" + tomorrowStr() + "\n1\n1\n0\n0\n");
    EXPECT_TRUE(contains(out, "Use a valid date as YYYY-MM-DD."));
    EXPECT_TRUE(contains(out, "Room  Type     Guests  Price/night"));
    EXPECT_TRUE(contains(out, "101"));
    EXPECT_TRUE(contains(out, "Rs. 1500"));
    EXPECT_FALSE(contains(out, "Rs. 2500"));
}

TEST_F(CliTest, AvailabilityWithImpossiblePriceFindsNothing) {
    std::string out = run("2\n" + tomorrowStr() + "\n1\n0\n1\n0\n");
    EXPECT_TRUE(contains(out, "No rooms found."));
}

TEST_F(CliTest, CheckInCancelAndServiceErrorsAreReported) {
    std::string out = run("4\n9\n6\n9\n7\n9\n10\n5\n9\n0\n");
    // check in, cancel, add service, check out on a booking that does not exist
    size_t count = 0, pos = 0;
    while ((pos = out.find("Error: No booking with that ID.", pos)) != std::string::npos) {
        ++count;
        ++pos;
    }
    EXPECT_EQ(count, 4u);
}

TEST_F(CliTest, CancelBooking) {
    int g = hotel_.registerGuest("Alice", "1");
    std::string err;
    ASSERT_GT(hotel_.book(g, 101, test::tomorrow(), 1, err), 0);
    std::string out = run("6\n1\n0\n");
    EXPECT_TRUE(contains(out, "Done."));
    EXPECT_EQ(hotel_.findBooking(1)->status, BookingStatus::Cancelled);
}

TEST_F(CliTest, FindGuestByIdAndByName) {
    int g = hotel_.registerGuest("Alice Smith", "555");
    hotel_.registerGuest("3rd Floor Guest", "777");
    std::string err;
    ASSERT_GT(hotel_.book(g, 101, test::tomorrow(), 1, err), 0);

    std::string byId = run("8\n1\n0\n");
    EXPECT_TRUE(contains(byId, "Guest 1: Alice Smith (555)"));
    EXPECT_TRUE(contains(byId, "Booking #1 | Alice Smith | Room 101"));
    EXPECT_TRUE(contains(byId, "Booked"));

    std::string byName = run("8\nsmith\n0\n");
    EXPECT_TRUE(contains(byName, "Alice Smith"));

    // A name that starts with digits is still searched as a name.
    std::string digitsName = run("8\n3rd\n0\n");
    EXPECT_TRUE(contains(digitsName, "3rd Floor Guest"));
    EXPECT_TRUE(contains(digitsName, "No bookings."));
}

TEST_F(CliTest, FindGuestNoMatch) {
    EXPECT_TRUE(contains(run("8\n42\n0\n"), "No guest found."));
    EXPECT_TRUE(contains(run("8\nnobody\n0\n"), "No guest found."));
}

TEST_F(CliTest, ListRoomsShowsOccupancy) {
    int g = hotel_.registerGuest("Alice", "1");
    std::string err;
    int b = hotel_.book(g, 101, test::tomorrow(), 1, err);
    ASSERT_TRUE(hotel_.checkIn(b, err));
    std::string out = run("9\n0\n");
    EXPECT_TRUE(contains(out, "Occupied"));
    EXPECT_TRUE(contains(out, "Free"));
    EXPECT_TRUE(contains(out, "Rs. 7000"));
}
