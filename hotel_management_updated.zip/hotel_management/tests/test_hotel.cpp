#include <gtest/gtest.h>

#include "hotel/date_utils.hpp"
#include "hotel/hotel.hpp"
#include "test_support.hpp"

using namespace hotel;

class HotelTest : public ::testing::Test {
protected:
    void SetUp() override { ASSERT_TRUE(hotel_.load()); }

    int addGuest(const std::string& name = "Alice", const std::string& phone = "555") {
        return hotel_.registerGuest(name, phone);
    }
    // Registers a guest and books `roomNo` starting tomorrow.
    int addBooking(int roomNo = 101, int nights = 2) {
        int g = addGuest();
        std::string err;
        int id = hotel_.book(g, roomNo, test::tomorrow(), nights, err);
        EXPECT_GT(id, 0) << err;
        return id;
    }

    test::TempDir dir_;
    Hotel hotel_{dir_.str()};
    std::string err_;
};

// ---------- rooms ----------
TEST_F(HotelTest, DefaultRoomsAreCreated) {
    EXPECT_EQ(hotel_.rooms().size(), 9u);
    ASSERT_NE(hotel_.findRoom(401), nullptr);
    EXPECT_EQ(hotel_.findRoom(401)->type(), RoomType::Suite);
    EXPECT_EQ(hotel_.findRoom(999), nullptr);
}

// ---------- guests ----------
TEST_F(HotelTest, GuestIdsIncrease) {
    EXPECT_EQ(addGuest("A"), 1);
    EXPECT_EQ(addGuest("B"), 2);
    ASSERT_NE(hotel_.findGuest(2), nullptr);
    EXPECT_EQ(hotel_.findGuest(2)->name, "B");
    EXPECT_EQ(hotel_.findGuest(3), nullptr);
}

TEST_F(HotelTest, GuestFieldsAreSanitisedForStorage) {
    int id = addGuest("Bad|Name\nHere", "12|3\r4");
    EXPECT_EQ(hotel_.findGuest(id)->name, "Bad Name Here");
    EXPECT_EQ(hotel_.findGuest(id)->phone, "12 3 4");
}

TEST_F(HotelTest, SearchIsCaseInsensitiveAndPartial) {
    addGuest("Alice Smith");
    addGuest("Bob Smithers");
    addGuest("Carol");
    EXPECT_EQ(hotel_.searchGuests("SMITH").size(), 2u);
    EXPECT_EQ(hotel_.searchGuests("carol").size(), 1u);
    EXPECT_TRUE(hotel_.searchGuests("zzz").empty());
}

// ---------- availability ----------
TEST_F(HotelTest, AllRoomsAvailableWhenNothingBooked) {
    EXPECT_EQ(hotel_.availableRooms(test::tomorrow(), 1, std::nullopt, 0).size(), 9u);
}

TEST_F(HotelTest, AvailabilityFiltersByTypeAndPrice) {
    const int d = test::tomorrow();
    EXPECT_EQ(hotel_.availableRooms(d, 1, RoomType::Single, 0).size(), 3u);
    EXPECT_EQ(hotel_.availableRooms(d, 1, RoomType::Suite, 0).size(), 1u);
    EXPECT_EQ(hotel_.availableRooms(d, 1, std::nullopt, 2500).size(), 6u);  // singles + doubles
    EXPECT_TRUE(hotel_.availableRooms(d, 1, std::nullopt, 100).empty());
    EXPECT_TRUE(hotel_.availableRooms(d, 1, RoomType::Suite, 2000).empty());
}

TEST_F(HotelTest, BookedRoomIsNotAvailableForOverlappingDates) {
    addBooking(101, 3);  // tomorrow .. tomorrow+3
    const int d = test::tomorrow();
    auto blocked = [&](int start, int nights) {
        for (const Room* r : hotel_.availableRooms(start, nights, RoomType::Single, 0))
            if (r->number() == 101) return false;
        return true;
    };
    EXPECT_TRUE(blocked(d, 1));
    EXPECT_TRUE(blocked(d + 2, 5));
    EXPECT_TRUE(blocked(d - 2, 3));
    EXPECT_FALSE(blocked(d + 3, 1));  // starts on the check-out day: free
    EXPECT_FALSE(blocked(d - 1, 1));  // ends on the check-in day: free
}

TEST_F(HotelTest, CancelledAndCheckedOutBookingsFreeTheRoom) {
    int id = addBooking(101);
    ASSERT_TRUE(hotel_.cancel(id, err_));
    EXPECT_EQ(hotel_.availableRooms(test::tomorrow(), 1, RoomType::Single, 0).size(), 3u);

    int id2 = addBooking(102);
    ASSERT_TRUE(hotel_.checkIn(id2, err_));
    std::string invoice;
    ASSERT_TRUE(hotel_.checkOut(id2, invoice, err_));
    EXPECT_EQ(hotel_.availableRooms(test::tomorrow(), 1, RoomType::Single, 0).size(), 3u);
}

// ---------- book ----------
TEST_F(HotelTest, BookSucceedsAndStoresDetails) {
    int g = addGuest();
    int id = hotel_.book(g, 201, test::tomorrow(), 4, err_);
    ASSERT_EQ(id, 1);
    const Booking* b = hotel_.findBooking(id);
    ASSERT_NE(b, nullptr);
    EXPECT_EQ(b->guestId, g);
    EXPECT_EQ(b->roomNo, 201);
    EXPECT_EQ(b->nights, 4);
    EXPECT_EQ(b->status, BookingStatus::Booked);
    EXPECT_DOUBLE_EQ(b->services, 0.0);
    EXPECT_EQ(hotel_.book(addGuest("Bob"), 202, test::tomorrow(), 1, err_), 2);
}

TEST_F(HotelTest, BookRejectsBadInput) {
    int g = addGuest();
    const int d = test::tomorrow();
    EXPECT_EQ(hotel_.book(99, 101, d, 1, err_), -1);
    EXPECT_EQ(err_, "No guest with that ID.");
    EXPECT_EQ(hotel_.book(g, 999, d, 1, err_), -1);
    EXPECT_EQ(err_, "No such room.");
    EXPECT_EQ(hotel_.book(g, 101, d, 0, err_), -1);
    EXPECT_EQ(err_, "Stay must be at least 1 night.");
    EXPECT_EQ(hotel_.book(g, 101, todayDay() - 1, 1, err_), -1);
    EXPECT_EQ(err_, "Check-in date is in the past.");
}

TEST_F(HotelTest, BookRejectsDoubleBooking) {
    addBooking(101, 2);
    int g2 = addGuest("Bob");
    EXPECT_EQ(hotel_.book(g2, 101, test::tomorrow() + 1, 2, err_), -1);
    EXPECT_EQ(err_, "Room is already booked for those dates.");
    EXPECT_GT(hotel_.book(g2, 101, test::tomorrow() + 2, 2, err_), 0);  // back-to-back is fine
}

TEST_F(HotelTest, BookingCanStartToday) {
    int g = addGuest();
    EXPECT_GT(hotel_.book(g, 101, todayDay(), 1, err_), 0) << err_;
}

TEST_F(HotelTest, BookingsForGuest) {
    int g = addGuest();
    int other = addGuest("Bob");
    hotel_.book(g, 101, test::tomorrow(), 1, err_);
    hotel_.book(g, 102, test::tomorrow(), 1, err_);
    hotel_.book(other, 103, test::tomorrow(), 1, err_);
    EXPECT_EQ(hotel_.bookingsFor(g).size(), 2u);
    EXPECT_EQ(hotel_.bookingsFor(other).size(), 1u);
    EXPECT_TRUE(hotel_.bookingsFor(999).empty());
    EXPECT_EQ(hotel_.findBooking(999), nullptr);
}

// ---------- check-in ----------
TEST_F(HotelTest, CheckInFlow) {
    int id = addBooking(101);
    EXPECT_FALSE(hotel_.isOccupiedToday(101));
    ASSERT_TRUE(hotel_.checkIn(id, err_));
    EXPECT_EQ(hotel_.findBooking(id)->status, BookingStatus::CheckedIn);
    EXPECT_TRUE(hotel_.isOccupiedToday(101));
    EXPECT_FALSE(hotel_.isOccupiedToday(102));
}

TEST_F(HotelTest, CheckInErrors) {
    EXPECT_FALSE(hotel_.checkIn(42, err_));
    EXPECT_EQ(err_, "No booking with that ID.");

    int id = addBooking(101);
    ASSERT_TRUE(hotel_.checkIn(id, err_));
    EXPECT_FALSE(hotel_.checkIn(id, err_));
    EXPECT_EQ(err_, "Booking is Checked in, cannot check in.");
}

TEST_F(HotelTest, CannotCheckInWhileRoomStillOccupied) {
    int g1 = addGuest("A"), g2 = addGuest("B");
    int first = hotel_.book(g1, 101, test::tomorrow(), 1, err_);
    int second = hotel_.book(g2, 101, test::tomorrow() + 1, 1, err_);
    ASSERT_TRUE(hotel_.checkIn(first, err_));
    EXPECT_FALSE(hotel_.checkIn(second, err_));
    EXPECT_EQ(err_, "Room is still occupied by another guest.");
}

// ---------- services ----------
TEST_F(HotelTest, AddServiceAccumulates) {
    int id = addBooking();
    ASSERT_TRUE(hotel_.checkIn(id, err_));
    ASSERT_TRUE(hotel_.addService(id, 100.5, err_));
    ASSERT_TRUE(hotel_.addService(id, 50, err_));
    EXPECT_DOUBLE_EQ(hotel_.findBooking(id)->services, 150.5);
}

TEST_F(HotelTest, AddServiceErrors) {
    EXPECT_FALSE(hotel_.addService(1, 10, err_));
    EXPECT_EQ(err_, "No booking with that ID.");

    int id = addBooking();
    EXPECT_FALSE(hotel_.addService(id, 10, err_));
    EXPECT_EQ(err_, "Services can only be added while checked in.");

    ASSERT_TRUE(hotel_.checkIn(id, err_));
    EXPECT_FALSE(hotel_.addService(id, 0, err_));
    EXPECT_EQ(err_, "Amount must be positive.");
    EXPECT_FALSE(hotel_.addService(id, -5, err_));
}

// ---------- cancel ----------
TEST_F(HotelTest, CancelFlowAndErrors) {
    EXPECT_FALSE(hotel_.cancel(1, err_));
    EXPECT_EQ(err_, "No booking with that ID.");

    int id = addBooking();
    ASSERT_TRUE(hotel_.cancel(id, err_));
    EXPECT_EQ(hotel_.findBooking(id)->status, BookingStatus::Cancelled);
    EXPECT_FALSE(hotel_.cancel(id, err_));
    EXPECT_EQ(err_, "Booking is Cancelled, cannot cancel.");

    int id2 = addBooking(102);
    ASSERT_TRUE(hotel_.checkIn(id2, err_));
    EXPECT_FALSE(hotel_.cancel(id2, err_));
    EXPECT_EQ(err_, "Booking is Checked in, cannot cancel.");
}

// ---------- check-out and invoice ----------
TEST_F(HotelTest, CheckOutProducesInvoiceWithGst) {
    int id = addBooking(101, 2);  // 2 x 1500 = 3000
    ASSERT_TRUE(hotel_.checkIn(id, err_));
    ASSERT_TRUE(hotel_.addService(id, 500, err_));

    std::string invoice;
    ASSERT_TRUE(hotel_.checkOut(id, invoice, err_));
    EXPECT_EQ(hotel_.findBooking(id)->status, BookingStatus::CheckedOut);
    EXPECT_NE(invoice.find("INVOICE"), std::string::npos);
    EXPECT_NE(invoice.find("Booking #1"), std::string::npos);
    EXPECT_NE(invoice.find("Alice"), std::string::npos);
    EXPECT_NE(invoice.find("Room 101 (Single)"), std::string::npos);
    EXPECT_NE(invoice.find("3000.00"), std::string::npos);  // room charge
    EXPECT_NE(invoice.find("3500.00"), std::string::npos);  // subtotal
    EXPECT_NE(invoice.find("420.00"), std::string::npos);   // 12% GST
    EXPECT_NE(invoice.find("3920.00"), std::string::npos);  // total
    EXPECT_FALSE(hotel_.isOccupiedToday(101));
}

TEST_F(HotelTest, CheckOutErrors) {
    std::string invoice;
    EXPECT_FALSE(hotel_.checkOut(5, invoice, err_));
    EXPECT_EQ(err_, "No booking with that ID.");

    int id = addBooking();
    EXPECT_FALSE(hotel_.checkOut(id, invoice, err_));
    EXPECT_EQ(err_, "Booking is Booked, cannot check out.");
    EXPECT_TRUE(invoice.empty());
}

TEST_F(HotelTest, InvoiceToleratesMissingGuestOrRoom) {
    Booking orphan{1, 77, 999, test::tomorrow(), 2, BookingStatus::CheckedOut, 0.0};
    std::string invoice = hotel_.invoiceFor(orphan);  // must not crash
    EXPECT_NE(invoice.find("Guest: ?"), std::string::npos);
    EXPECT_NE(invoice.find("Room 999 (?)"), std::string::npos);
}
